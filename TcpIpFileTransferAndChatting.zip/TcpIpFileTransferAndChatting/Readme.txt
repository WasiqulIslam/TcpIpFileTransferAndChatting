Please run this program by double-clicking the 'Run.bat' file (in Windows systems).

If you use Linux or Mac, please get in touch with me to learn how to run it.
